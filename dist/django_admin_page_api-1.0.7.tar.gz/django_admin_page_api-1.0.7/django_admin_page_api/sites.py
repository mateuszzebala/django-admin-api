
from django.urls import include

urls = include('django_admin_page_api.urls')


